# What is still owed — `todo/`

Carried over from `progress.md` on 2026-09-17. **18 of 33 steps done, 15 open.** Step numbers are the frozen numbers of `progress.md`; this file is a working copy of its open items, not a second source of truth. A step closes in `progress.md`, not here.

Every CSV in this folder is a skeleton. The dimension columns — dataset, backbone, selector, K, partition, rank — are already filled in from Table 4, Table 9 and `priority_1/full_matrix.csv`. The value columns are empty and are what is owed. Comma-delimited, like `full_matrix.csv`. Dataset and selector strings match `full_matrix.csv` exactly, so each file joins back without a lookup.

Filled files go to `priority_2/` under the names `progress.md` specifies.

| File | Step | Rows | What is owed | Closes the step alone? |
|---|---|---|---|---|
| `09_psi.csv` | 9 | 12 | `psi_mean`, `psi_median`, `psi_max`, `psi_max_feature` | yes |
| `01_obfuscation.csv` | 1 | 4 | `ho_auc` and five fold AUCs | **no — three more items, below** |
| `06_leakage.csv` | 6 | 0 | the flagged features, one per row | yes, if all are outside the 373 |
| `08_boruta.csv` | 8 | 108 | `n_selected` | yes, if every fold hit its budget |
| `10_stability.csv` | 10 | 82 | `d`, `nogueira`, `jaccard_mean`, `jaccard_min`, `jaccard_max` | yes |
| `11_subsets.csv` | 11 | 360 | `feature` | yes |
| `12_overlap.csv` | 12 | 4 | the three count columns | yes |
| `15_cohort.csv` | 15 | 6 | `ho_auc`, `dev_oof_auc` | yes |
| `16_l1.csv` | 16 | 6 | `ho_auc`, `dev_oof_auc` | yes |
| `17_mrmr.csv` | 17 | 2 | `seconds` | yes |
| `21_brier.csv` | 21 | 84 | `brier` | yes |

Steps **19, 22, 23 and 24** need no CSV. 19 is a write-up blocked behind 1; 22 and 23 are your actions on the repository; 24 is the final build and is strictly last.

---

## Gate 0 — B6, and the write-up that waits on it

### 1. Name obfuscation, both arms `[Both]`

Home Credit only. Six ranking calls per arm, five folds plus full DEV. Everything identical to the cached run except the feature records: snapshot `gpt-4.1-mini-2025-04-14`, temperature 0, JSON response format, the Appendix A template unchanged, `definitions_only`, the same candidate set per fold, the same strict validation (exactly 100 distinct names present verbatim, up to three retries, no fallback). Then twelve refits — top 20 to logistic regression, top 40 to CatBoost, five folds plus the full-DEV refit each — and HO scoring on the same 120,053 rows.

- **Arm A, names removed.** Replace every name with `F001 …` by a **seeded shuffle**, not alphabetical or file order, and record the seed. Scrub every literal occurrence of the original name from inside the description text as well as the name field, or a record still reads `EXT_SOURCE_3` in its own definition.
- **Arm B, descriptions removed.** Names kept, descriptions blank.

**Four deliverables. Only the first is templated here.**

1. `01_obfuscation.csv` — filled in with both arms × both backbones; four rows of AUCs owed.
2. `obfuscated_lists_armA.csv` and `obfuscated_lists_armB.csv` — `dataset,partition,rank,feature_id,original_feature_name`, 600 rows each, `partition` in fold1..fold5 and full_dev. The original-name column is the de-obfuscation key and never goes to the model. Not templated because the rows are model output rather than a fixed grid.
3. **One line** confirming snapshot, temperature, template and evidence mode were unchanged, and giving the **shuffle seed**.
4. **The named Home Credit per-fold rankings** — same schema as (2), 600 rows. B6 asks me to compute the overlap between obfuscated and named lists, and these are **not anywhere on disk**. Without them the ablation has nothing to be compared against.

*Optional but upgrades the result from descriptive to tested:* one pairwise row per arm and backbone from the routine that produced `priority_1/pairwise.csv`, obfuscated against named — 0.743635 for logistic regression and 0.793450 for CatBoost.

### 19. B6 result `[Claude]` — no CSV, blocked by step 1

I write this once step 1 lands. The branch is already decided:

- **AUC holds, lists overlapping** → one Results paragraph, one Discussion paragraph; the memorisation paragraph shortens to a resolved point.
- **AUC holds, lists diverging** → the same, plus one clause tying it to the non-determinism already reported.
- **AUC drops materially** → reported as a negative; the contribution narrows to datasets the model has seen; abstract, contributions list and conclusion rewritten.

In every branch the `EXT_SOURCE_1/2/3` ordering is disclosed in the same paragraph, volunteered rather than extracted.

---

## First priority

### 9. Selected-feature PSI `[Both]` → `09_psi.csv`

DEV-versus-HO PSI of the features selected by the frozen full-DEV refit, binning as in Section 5.5. The twelve Table 4 leaders — six LLM-assisted, six classical. All 78 pipelines would be better but twelve closes the step. I then add two columns to Table 4, rewrite the Section 6.2 drift paragraph to describe the leaders instead of minima, and replace the Section 7.3 caveat. On Home Credit `psi_max_feature` doubles as the check on step 7.

*Check that runs on delivery:* `psi_mean` cannot exceed `(psi_median + psi_max)/2`, since at least half the features sit at or below the median.

## Gate 1

### 6. Domain-rules leakage flags `[Authors]` → `06_leakage.csv`

The Home Credit features the domain-rules scorer marks as leakage, and for each whether it sits inside or outside the 373-feature candidate set. All outside → one sentence in Section 4.3 and the step closes. Any inside → I need `11_subsets.csv` too, to say whether a headline subset contains it.

### 8. Realised Boruta subset sizes `[Both]` → `08_boruta.csv`

Every cell: three Boruta-stage selectors × six cases × six partitions. A below-budget LLM then Boruta explains its weakness rather than indicting the LLM. It also decides whether the analytic 529-to-373 conversion of the two Home Credit LLM-then-Boruta rows in Table 9 (0.4294, 0.4204) stands — exact only if every fold hit the budget. **If any fold was short, those two cells must be recomputed directly from the fold lists**, which is a further deliverable not templated here.

### 10. Nogueira and Jaccard for every refitted selector `[Both]` → `10_stability.csv`

82 rows: the `full_matrix.csv` grid minus pure LLM (a cached ranking, not a refit), plus the four pure LLM rows that already appear in Table 9 and need only `jaccard_min` and `jaccard_max` — their Nogueira and mean Jaccard are pre-filled from the table. No stability statistic in the paper carries any uncertainty, while every AUC difference carries an interval. Table 9 grows; RQ2 stops resting on bare points.

### 11. The twelve headline subsets `[Both]` → `11_subsets.csv`

Four are buildable now from the cached rankings — pure LLM on Home Credit CatBoost, LendingClub LR, Stability LR and Stability CatBoost. Goes to an appendix. Partly answers B6 for free, and answers step 6's second branch.

### 12. Two LendingClub counts `[Both]` → `12_overlap.csv`

For each leader, how many selected features share a base column with another selected feature. Nothing about redundancy enters the paper until this exists; one version of the story was tested and refuted on 2026-09-14.

## Gate 2 — decide DO or CONCEDE

### 15. Stability cohort re-run `[Authors]` → `15_cohort.csv`

Six fits, no selection: the two full-feature references and the four headline refits on the 2020-02-01 cohort. **Default: DO.** It retires eleven cross-cohort caveats and Table 4 note (a). Concede: already conceded in Limitations, no text change.

### 16. L1-penalised logistic regression as a selector `[Authors]` → `16_l1.csv`

Six cases on existing infrastructure. **Default: DO** — it is the standard comparator in both papers the Related Work cites for this line. Concede: one Related Work sentence saying why it was not run.

### 17. Time mRMR against pool size `[Authors]` → `17_mrmr.csv`

1,959 against 100 features, one dataset, same machine and fold. **Default: DO** — it is the only measured answer to "why is this a big-data paper". Concede: Section 6.4 stands as written.

## Gate 3 — freeze

### 21. Brier column of Table 8 `[Authors]` → `21_brier.csv`

84 rows keyed to `full_matrix.csv`. The HO Brier score of the frozen full-DEV refit, on the same HO prediction vector that produced `ho_auc`, `ks` and `capture10`. I merge it in as the eighth field of `full_matrix.csv`, between `capture10` and `fold1_auc`, rebuild the Brier column of Table 8 and re-verify the two prose claims in Sections 6.2 and 7.4.

### 22. Repository alignment `[Authors]` — no CSV

Five separate items. The first is the only one that can move text in the paper.

**22a. The cache metadata contradicts the paper — decide which is right.**
The cached fold responses carry `max_missing_rate: 0.95` and `n_candidates: 374`. The paper says the screen is **at most 90% missing** and the candidate set is **373 of 529** (Sections 4.1, 4.5, 5.1, Table 3, Table 9's `d`, Appendix C — 19 occurrences of "373"). A referee who downloads the repository sees 0.95/374 beside a paper saying 90%/373.

Two outcomes, and they are not symmetric:
- **The paper is right, the cache metadata is stale** → correct the two fields in the cached responses before release. Nothing in the manuscript changes. This is the expected case.
- **The cache is right** → the screen was 95% and the candidate set is 374, and 19 places in the manuscript are wrong, including Table 3, the Nogueira universe in Table 9 and the full-pool mRMR row of Appendix C. Tell me immediately if so; this is a large edit, not a footnote.

**22b.** `repeated_calls_pairwise_jaccard.csv` is stale against the current `repeated_calls_lists.csv` — **4 of its 90 rows** no longer recompute (all four are pairs involving repeat 1 at K=40). Regenerate it from the lists. I do not use this file for any manuscript number, so nothing in the text depends on it; it matters only for the release.

**22c.** `repeated_calls_contract_issues.csv` ends with a trailing empty row. Delete it.

**22d.** `homecredit_rankings.csv` has **two corrupted rows** — line 307 (`fold4`, rank 6) and line 310 (`fold4`, rank 9) each carry a stray sixth value, `EXT_SOURCE_2` and `AMT_INCOME_TOTAL`. Both duplicate names already present at other ranks in that fold, so they look like paste artefacts, but this column is the de-obfuscation key and has to be exact. It also ends with a trailing empty row.

**22e.** ~~`stability_monthly_ho_auc_20202626.csv` — `20202626` is not a date.~~ **Done 2026-09-17:** renamed to `stability_monthly_ho_auc_20200201.csv` (the file is the 2020-02-01 cohort, its `n` summing to 369,147), and the reference in `progress.md` updated. The five `priority_2/repeated_calls_* (1).csv` downloads were renamed to their clean names at the same time, which is what `tasks.md` and this file already called them.

### 23. DOI release `[Authors]` — no CSV

Versioned archive, Zenodo or equivalent, with code, configuration, cached rankings, freeze manifest and the HO score vectors of the twelve headline pipelines. Data availability then cites the DOI rather than a bare repository URL. Do this after 22.

### 24. Final build `[Claude]` — no CSV

0 errors, 0 undefined references, 0 overfull; PDF metadata checked; `manuscript.pdf` refreshed. Strictly last.
